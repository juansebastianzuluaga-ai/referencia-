// Content script inyectado en la aplicación de referencia (ver "matches" en
// manifest.json). Es el puente entre la página web (que no puede hablar
// directo con la extensión) y el background script:
//
//   página (postMessage) → content-bridge.js → background.js → Gomedisys
//
// Reenvía cada solicitud de autocompletar y devuelve el resultado.
//
// Se usa una conexión de puerto (chrome.runtime.connect), no un mensaje
// suelto — el diligenciamiento puede tardar varios segundos y un mensaje
// "de una sola vez" corre el riesgo de que Chrome dé el intercambio por
// cerrado antes de que llegue la respuesta.

console.log('[Gomedisys ext] content-bridge.js cargado en', location.href);

window.addEventListener('message', (ev) => {
  if (ev.source !== window) return;
  const datos = ev.data;
  if (!datos || datos.source !== 'referencia-app' || datos.type !== 'autocompletar') return;
  console.log('[Gomedisys ext] pedido recibido de la app:', datos);

  const responder = (resultado) => {
    console.log('[Gomedisys ext] respondiendo a la app:', resultado);
    window.postMessage(
      { source: 'gomedisys-extension', type: 'autocompletar-resultado', requestId: datos.requestId, ...resultado },
      window.location.origin,
    );
  };

  let puerto;
  try {
    puerto = chrome.runtime.connect({ name: 'referencia-bridge' });
  } catch (err) {
    responder({ ok: false, error: 'No se pudo conectar con la extensión: ' + err.message });
    return;
  }

  let respondido = false;
  puerto.onMessage.addListener((resultado) => {
    respondido = true;
    responder(resultado);
    puerto.disconnect();
  });
  puerto.onDisconnect.addListener(() => {
    if (respondido) return;
    responder({ ok: false, error: 'Se perdió la conexión con la extensión antes de recibir una respuesta.' });
  });
  puerto.postMessage({ type: 'autocompletar', solicitud: datos.solicitud });
});
