// Content script inyectado en las pestañas de Gomedisys (ver manifest.json).
// Diligencia el formulario "Registro de Referencia" usando la pestaña que
// el personal YA tiene abierta y con sesión iniciada — nunca toca login ni
// reCAPTCHA, nunca abre una pestaña nueva por su cuenta.
//
// Es la misma secuencia validada en ../diligenciar.js + ../kendoHelpers.js
// (con Playwright), reescrita en DOM puro porque un content script no tiene
// Playwright disponible: solo puede manipular la página real con las APIs
// normales del navegador.
//
// NUNCA hace clic en "Agregar registro" (Guardar) — deja el formulario
// diligenciado, listo para que una persona lo revise y decida.
//
// El trabajo se coordina por chrome.storage.session, NO por una conexión
// directa (puerto/mensaje) — el clic en el menú de Gomedisys dispara una
// navegación real de página (confirmado probando en vivo), y eso mata
// cualquier conexión directa a mitad de camino. storage.session, en
// cambio, sobrevive a la navegación: cuando la página nueva carga, este
// mismo script se vuelve a inyectar solo (por manifest.json) y retoma el
// trabajo pendiente donde estaba.

// Guarda contra doble inyección: background.js inyecta este script a
// propósito antes de cada uso (además de la inyección automática por
// manifest.json) para asegurar una copia siempre viva, sin depender de que
// la primera inyección haya sobrevivido. Sin esta guarda, la segunda
// inyección redeclararía `const`/`function` de nivel superior y volvería a
// registrar los listeners por duplicado.
if (window.__gomedisysAutocompletarCargado) {
  console.log('[Gomedisys ext] content-gomedisys.js ya estaba cargado, no se vuelve a inicializar.');
} else {
window.__gomedisysAutocompletarCargado = true;

const MAPA_GENERO = { M: 'Hombre', F: 'Mujer' };

function dormir(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Espera a que exista un elemento que cumpla `selector` — Kendo y el resto
// del formulario cargan piezas de forma asíncrona, así que no basta con
// buscar una sola vez.
function esperarSelector(selector, { timeout = 15000, raiz = document } = {}) {
  return new Promise((resolve, reject) => {
    const existente = raiz.querySelector(selector);
    if (existente) return resolve(existente);

    const observer = new MutationObserver(() => {
      const el = raiz.querySelector(selector);
      if (el) {
        observer.disconnect();
        resolve(el);
      }
    });
    observer.observe(raiz === document ? document.documentElement : raiz, {
      childList: true,
      subtree: true,
      attributes: true,
    });
    setTimeout(() => {
      observer.disconnect();
      reject(new Error(`No apareció "${selector}" a tiempo.`));
    }, timeout);
  });
}

function normalizarTexto(texto) {
  return (texto || '').trim().replace(/\s+/g, ' ').toLowerCase();
}

function coincideTexto(el, textoOMatch) {
  const texto = (el.textContent || '').trim();
  if (textoOMatch instanceof RegExp) return textoOMatch.test(texto);
  // Comparación insensible a mayúsculas/espacios — el texto real de
  // Gomedisys no siempre coincide en formato exacto con nuestro dato.
  return normalizarTexto(texto) === normalizarTexto(textoOMatch);
}

// Entre varios elementos que coinciden con el texto, se prefiere el más
// específico (el que ningún otro candidato contiene) — así no se hace clic
// en un contenedor grande cuando lo que se quería era la etiqueta pequeña
// de adentro.
function buscarPorTexto(selector, textoOMatch, raiz = document) {
  const candidatos = Array.from(raiz.querySelectorAll(selector)).filter((el) => coincideTexto(el, textoOMatch));
  return candidatos.find((el) => !candidatos.some((otro) => otro !== el && el.contains(otro))) || candidatos[0] || null;
}

function esperarTexto(selector, textoOMatch, { timeout = 15000 } = {}) {
  return new Promise((resolve, reject) => {
    const existente = buscarPorTexto(selector, textoOMatch);
    if (existente) return resolve(existente);

    const observer = new MutationObserver(() => {
      const el = buscarPorTexto(selector, textoOMatch);
      if (el) {
        observer.disconnect();
        resolve(el);
      }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    setTimeout(() => {
      observer.disconnect();
      reject(new Error(`No apareció texto "${textoOMatch}" a tiempo.`));
    }, timeout);
  });
}

// Simula un clic real (mousedown/mouseup/click) — los widgets de Kendo
// escuchan estos eventos con jQuery, que sí reacciona a eventos disparados
// por código, no solo a los del usuario.
function clic(el) {
  el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
  el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
  el.click();
}

// Pone el valor de un <input>/<textarea> usando el setter nativo de SU
// PROPIO tipo (no el de una posible clase que lo envuelva) y dispara
// 'input'/'change' — así los widgets que escuchan esos eventos (Kendo,
// validación de ASP.NET) se enteran del cambio, igual que si la persona
// hubiera escrito. El setter de "value" es distinto entre <input> y
// <textarea> (son interfaces distintas) — usar siempre el de
// HTMLInputElement revienta con "Illegal invocation" en un <textarea>
// (como #clinicalSummary), así que se toma el del prototipo real del
// elemento en vez de asumir cuál es.
function ponerValor(el, valor) {
  const descriptor = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
  if (descriptor && descriptor.set) {
    descriptor.set.call(el, valor);
  } else {
    el.value = valor;
  }
  el.dispatchEvent(new Event('input', { bubbles: true }));
  el.dispatchEvent(new Event('change', { bubbles: true }));
}

function opcionesDisponibles(listbox) {
  return Array.from(listbox.querySelectorAll('li, [role="option"]'))
    .map((el) => el.textContent.trim())
    .filter(Boolean);
}

async function seleccionarKendoDropdown(idCampo, textoOpcion) {
  const combobox = await esperarSelector(`span[role="combobox"][aria-controls="${idCampo}_listbox"]`);
  clic(combobox);
  const listbox = await esperarSelector(`#${idCampo}_listbox`);
  const opcion = buscarPorTexto('li, [role="option"]', textoOpcion, listbox);
  if (!opcion) {
    // Se listan las opciones reales en el error — así, si el texto no
    // coincide, se sabe de una vez qué SÍ hay disponible, sin adivinar.
    throw new Error(`No encontré la opción "${textoOpcion}" en ${idCampo}. Opciones disponibles: ${opcionesDisponibles(listbox).join(' | ')}`);
  }
  clic(opcion);
}

async function seleccionarKendoComboBox(idCampo, textoBusqueda, textoOpcion) {
  // El input real de este widget no siempre tiene `id` propio (solo
  // `name`) — se busca por name para no depender de que exista.
  const input = await esperarSelector(`[name="${idCampo}_input"]`);

  // Si este mismo campo ya se usó antes en la sesión (ej. una solicitud
  // anterior en la misma pestaña), la lista puede seguir mostrando esas
  // opciones viejas hasta que la búsqueda nueva las reemplace — se guarda
  // una "foto" de lo que hay ANTES de escribir, para poder distinguir
  // resultados viejos de resultados nuevos.
  const listboxPrevio = document.querySelector(`#${idCampo}_listbox`);
  const opcionesAntes = listboxPrevio ? opcionesDisponibles(listboxPrevio).join('|') : null;

  clic(input);
  ponerValor(input, textoBusqueda);
  const listbox = await esperarSelector(`#${idCampo}_listbox`);

  // Se espera a que la lista tenga opciones DISTINTAS a las de antes — no
  // solo "que tenga algo" (podría ser la lista vieja sin reemplazar
  // todavía). La búsqueda es asíncrona en el servidor.
  await new Promise((resolve) => {
    const listo = () => {
      const actuales = opcionesDisponibles(listbox).join('|');
      return actuales.length > 0 && actuales !== opcionesAntes;
    };
    if (listo()) return resolve();
    const observer = new MutationObserver(() => {
      if (listo()) {
        observer.disconnect();
        resolve();
      }
    });
    observer.observe(listbox, { childList: true, subtree: true });
    setTimeout(() => {
      observer.disconnect();
      resolve();
    }, 8000);
  });

  const opcion = textoOpcion
    ? buscarPorTexto('li, [role="option"]', textoOpcion, listbox)
    : listbox.querySelector('li, [role="option"]');
  if (!opcion) {
    throw new Error(`No encontré ninguna opción en ${idCampo} para "${textoBusqueda}". Opciones disponibles: ${opcionesDisponibles(listbox).join(' | ')}`);
  }
  clic(opcion);
}

async function diligenciarFormulario(solicitud, onPaso = () => {}) {
  // Si ya estamos en el formulario o en el listado (por ejemplo, retomando
  // después de que el clic en el menú navegó a otra página), no hace falta
  // repetir la navegación por el menú — se salta directo a lo que falte.
  const yaEnFormulario = !!document.querySelector('#documentNumberPatient');
  const yaEnListado = !yaEnFormulario && !!document.querySelector('#btnNewRecord');

  if (!yaEnFormulario && !yaEnListado) {
    onPaso('Revisando si pide seleccionar sede...');
    const botonConfirmarSede = await esperarTexto('button', /confirmar/i, { timeout: 5000 }).catch(() => null);
    if (botonConfirmarSede) {
      onPaso('Seleccionando sede "Urgencias"...');
      const urgencias = await esperarTexto('*', /urgencias/i, { timeout: 5000 });
      clic(urgencias);
      clic(botonConfirmarSede);
    }

    onPaso('Abriendo el menú...');
    clic(await esperarSelector('#menuID'));

    onPaso('Buscando "Registro de Referencia"...');
    const barraBusqueda = await esperarSelector('#searchInputMenu');
    ponerValor(barraBusqueda, 'referencia');
    const linkReferencia = await esperarTexto('.menu-link__label', 'Registro de Referencia');
    clic(linkReferencia);
  }

  if (!yaEnFormulario) {
    onPaso('Abriendo formulario nuevo...');
    clic(await esperarSelector('#btnNewRecord'));
  }

  onPaso('Diligenciando campos...');
  ponerValor(await esperarSelector('#documentNumberPatient'), solicitud.documento);
  ponerValor(await esperarSelector('#givenNamePatient'), solicitud.nombres);
  ponerValor(await esperarSelector('#familyNamePatient'), solicitud.apellidos);
  ponerValor(await esperarSelector('#age'), solicitud.edad);

  if (solicitud.direccionPaciente) {
    ponerValor(await esperarSelector('#addressPatient'), solicitud.direccionPaciente);
  }
  if (solicitud.telefonoPaciente) {
    ponerValor(await esperarSelector('#telecomPatient'), solicitud.telefonoPaciente);
  }

  onPaso('Seleccionando "Ciudad de Origen"...');
  // solicitud.ciudadOrigen ya viene como "Municipio, Departamento" (tal
  // cual lo escribió la persona, en el mismo formato que usa Gomedisys).
  // El buscador de Gomedisys filtra por el nombre de la ciudad — mandarle
  // el texto completo con el departamento de una vez no trae resultados
  // (confirmado probando en vivo), así que se filtra solo con la parte
  // antes de la coma, y se usa el texto completo para elegir la opción
  // exacta entre lo que aparezca filtrado — Gomedisys tiene varios
  // municipios con el mismo nombre en departamentos distintos y sin esto
  // se puede elegir el equivocado en silencio.
  const nombreCiudad = solicitud.ciudadOrigen.split(',')[0].trim();
  await seleccionarKendoComboBox('idHomePoliticalDivisionPatient', nombreCiudad, solicitud.ciudadOrigen);

  onPaso('Seleccionando "Servicio que refiere"...');
  await seleccionarKendoDropdown('idServiceReferral', solicitud.servicioRemision);

  onPaso('Seleccionando "Género"...');
  await seleccionarKendoDropdown('idGenere', MAPA_GENERO[solicitud.genero]);

  ponerValor(await esperarSelector('#clinicalSummary'), solicitud.resumenClinico);

  onPaso('Abriendo el buscador de diagnóstico...');
  clic(await esperarSelector('#openDiagnosticLookupBtn'));
  const campoDx = await esperarSelector('#findCodeDxICD10-coRef');
  ponerValor(campoDx, solicitud.diagnosticoCodigo);
  // La búsqueda del código es asíncrona en el servidor de Gomedisys — sin
  // esta espera el clic en "Incluir" cae en el vacío.
  await dormir(1500);
  clic(await esperarSelector('#add-diagnostic-btn-coRef'));

  onPaso('Formulario diligenciado.');
}

const CLAVE_TRABAJO = 'gomedisysTrabajo';
let procesando = false;

async function revisarTrabajoPendiente(gatillo) {
  if (procesando) return;
  const datos = await chrome.storage.session.get(CLAVE_TRABAJO);
  const trabajo = datos[CLAVE_TRABAJO];
  if (!trabajo || trabajo.estado !== 'pendiente') return;

  procesando = true;
  console.log(`[Gomedisys ext] retomando trabajo pendiente (${gatillo}).`);
  try {
    await diligenciarFormulario(trabajo.solicitud, (paso) => console.log('[Gomedisys ext] paso:', paso));
    console.log('[Gomedisys ext] diligenciado OK.');
    await chrome.storage.session.set({ [CLAVE_TRABAJO]: { ...trabajo, estado: 'completado' } });
  } catch (err) {
    console.error('[Gomedisys ext] error diligenciando:', err);
    await chrome.storage.session.set({ [CLAVE_TRABAJO]: { ...trabajo, estado: 'error', error: err.message } });
  } finally {
    procesando = false;
  }
}

console.log('[Gomedisys ext] content-gomedisys.js cargado en', location.href);
revisarTrabajoPendiente('carga de página');

chrome.storage.onChanged.addListener((cambios, area) => {
  if (area !== 'session' || !cambios[CLAVE_TRABAJO]) return;
  revisarTrabajoPendiente('cambio de storage');
});

} // fin de la guarda contra doble inyección
